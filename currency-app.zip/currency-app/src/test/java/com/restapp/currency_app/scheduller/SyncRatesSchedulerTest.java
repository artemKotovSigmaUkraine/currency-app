package com.restapp.currency_app.scheduller;

import static java.math.BigDecimal.TEN;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.restapp.currency_app.entity.Currency;
import com.restapp.currency_app.service.CurrencyDataService;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class SyncRatesSchedulerTest {

    @Mock
    private CurrencyDataService currencyDataService;
    @InjectMocks
    private SyncRatesScheduler syncRatesScheduler;

    @Test
    void scheduleRatesSyncTaskTest() {
        List<Currency> testCurrencies = List.of(new Currency(1L, "EUR", TEN));
        when(currencyDataService.getFreshCurrencyData()).thenReturn(testCurrencies);

        syncRatesScheduler.scheduleRatesSyncTask();

        verify(currencyDataService).getFreshCurrencyData();
        verify(currencyDataService).updateRatesInDB(testCurrencies);
    }

}
