package com.restapp.currency_app.service;

import static com.restapp.currency_app.service.CurrencyDataService.toCurrencyName;
import static java.math.BigDecimal.ONE;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.restapp.currency_app.dto.CurrencyDto;
import com.restapp.currency_app.dto.RateDto;
import com.restapp.currency_app.entity.Currency;
import com.restapp.currency_app.repository.CurrencyRepository;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.modelmapper.ModelMapper;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.RestTemplate;

@ExtendWith(MockitoExtension.class)
public class CurrencyDataServiceTest {

    @Mock
    private CurrencyRepository currencyRepository;
    @Mock
    private ModelMapper modelMapper;
    @Mock
    private RestTemplate restTemplate;

    @InjectMocks
    private CurrencyDataService currencyDataService;

    public static final String TEST_CURRENCY_NAME = "USD";
    public static final String TEST_EXTERNAL_RESOURCE_URL = "http://test.test";
    public static final String EXTERNAL_RESOURCE_URL_PARAM_NAME = "exchangeratesapiPath";
    public static final String LAST_CURRENCY_RATES_PARAM_NAME = "lastCurrencyRates";
    public static final String CURRENCY_DATA_SERVICE_PARAM_NAME = "currencyDataService";

    @Test
    void getLastCurrencyRates_mapOfLastCurrencyRatesIsEmpty() {
        ReflectionTestUtils.setField(currencyDataService, CURRENCY_DATA_SERVICE_PARAM_NAME, currencyDataService);
        ReflectionTestUtils.setField(currencyDataService, LAST_CURRENCY_RATES_PARAM_NAME, new HashMap());
        ReflectionTestUtils.setField(currencyDataService, EXTERNAL_RESOURCE_URL_PARAM_NAME, TEST_EXTERNAL_RESOURCE_URL);
        when(restTemplate.getForObject(eq(TEST_EXTERNAL_RESOURCE_URL), eq(RateDto.class)))
            .thenReturn(new RateDto(true, 1L, "", "", Map.of(TEST_CURRENCY_NAME, ONE)));
        CurrencyDto expectedCurrencyDto = new CurrencyDto(TEST_CURRENCY_NAME, ONE);
        Currency expectedCurrency = new Currency(null, TEST_CURRENCY_NAME, ONE);
        when(modelMapper.map(eq(expectedCurrencyDto), eq(Currency.class))).thenReturn(expectedCurrency);

        Map<String, BigDecimal> actual = currencyDataService.getLastCurrencyRates();

        assertEquals(Map.of(TEST_CURRENCY_NAME, ONE), actual);
        verify(restTemplate).getForObject(anyString(), any());
        verify(currencyRepository).deleteAll();
        verify(currencyRepository).flush();
        verify(currencyRepository).saveAll(List.of(expectedCurrency));
    }

    @Test
    void getLastCurrencyRates_mapOfLastCurrencyRatesIsNotEmpty() {
        ReflectionTestUtils.setField(currencyDataService, CURRENCY_DATA_SERVICE_PARAM_NAME, currencyDataService);
        Map<String, BigDecimal> map = new HashMap();
        map.put(TEST_CURRENCY_NAME, ONE);
        ReflectionTestUtils.setField(currencyDataService, LAST_CURRENCY_RATES_PARAM_NAME, map);

        Map<String, BigDecimal> actual = currencyDataService.getLastCurrencyRates();

        assertEquals(Map.of(TEST_CURRENCY_NAME, ONE), actual);
        verify(restTemplate, never()).getForObject(anyString(), any());
        verify(currencyRepository, never()).deleteAll();
        verify(currencyRepository, never()).flush();
        verify(currencyRepository, never()).saveAll(any());
    }

    @Test
    void changeLastCurrencyRateTest() {
        Map<String, BigDecimal> map = new HashMap();
        map.put(TEST_CURRENCY_NAME, ONE);
        ReflectionTestUtils.setField(currencyDataService, LAST_CURRENCY_RATES_PARAM_NAME, map);
        Currency expectedCurrency = new Currency(null, TEST_CURRENCY_NAME, ONE);

        currencyDataService.changeLastCurrencyRate(expectedCurrency);

        Map<String, BigDecimal> lastCurrencyRatesAfterChange =
            (Map<String, BigDecimal>) ReflectionTestUtils.getField(currencyDataService, LAST_CURRENCY_RATES_PARAM_NAME);
        assertEquals(Map.of(expectedCurrency.getName(), expectedCurrency.getRate()), lastCurrencyRatesAfterChange);
    }

    @Test
    void updateRatesInDBTest() {
        List<Currency> currencies = List.of(new Currency(1L, TEST_CURRENCY_NAME, ONE));

        currencyDataService.updateRatesInDB(currencies);

        verify(currencyRepository).deleteAll();
        verify(currencyRepository).flush();
        verify(currencyRepository).saveAll(currencies);
    }

    @Test
    void getFreshCurrencyData_someDataReceivedFromExternalResource() {
        ReflectionTestUtils.setField(currencyDataService, EXTERNAL_RESOURCE_URL_PARAM_NAME, TEST_EXTERNAL_RESOURCE_URL);
        CurrencyDto expectedCurrencyDto = new CurrencyDto(TEST_CURRENCY_NAME, ONE);
        Currency expectedCurrency = new Currency(null, TEST_CURRENCY_NAME, ONE);
        when(restTemplate.getForObject(eq(TEST_EXTERNAL_RESOURCE_URL), eq(RateDto.class)))
            .thenReturn(new RateDto(true, 1L, "", "", Map.of(TEST_CURRENCY_NAME, ONE)));
        when(modelMapper.map(eq(expectedCurrencyDto), eq(Currency.class))).thenReturn(expectedCurrency);

        List<Currency> actual = currencyDataService.getFreshCurrencyData();

        assertEquals(List.of(expectedCurrency), actual);
        verify(restTemplate).getForObject(TEST_EXTERNAL_RESOURCE_URL, RateDto.class);
        verify(modelMapper).map(expectedCurrencyDto, Currency.class);
    }

    @Test
    void getFreshCurrencyData_emptyDataReceivedFromExternalResource() {
        ReflectionTestUtils.setField(currencyDataService, EXTERNAL_RESOURCE_URL_PARAM_NAME, TEST_EXTERNAL_RESOURCE_URL);
        when(restTemplate.getForObject(eq(TEST_EXTERNAL_RESOURCE_URL), eq(RateDto.class))).thenReturn(null);

        List<Currency> actual = currencyDataService.getFreshCurrencyData();

        assertEquals(List.of(), actual);
        verify(restTemplate).getForObject(TEST_EXTERNAL_RESOURCE_URL, RateDto.class);
        verify(modelMapper, never()).map(any(), any());
    }

    @Test
    void toCurrencyName_inputDataInLowerCaseFormat() {
        assertEquals(TEST_CURRENCY_NAME, toCurrencyName(TEST_CURRENCY_NAME.toLowerCase()));
    }

    @Test
    void toCurrencyName_inputDataInUpperCaseFormat() {
        assertEquals(TEST_CURRENCY_NAME, toCurrencyName(TEST_CURRENCY_NAME.toUpperCase()));
    }

    @Test
    void toCurrencyName_inputDataInCamelCaseFormat() {
        assertEquals(TEST_CURRENCY_NAME, toCurrencyName("uSd"));
    }

}
