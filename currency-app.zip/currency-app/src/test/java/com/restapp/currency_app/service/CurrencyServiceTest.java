package com.restapp.currency_app.service;

import static java.math.BigDecimal.ONE;
import static java.math.BigDecimal.TWO;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.restapp.currency_app.dto.CurrencyDto;
import com.restapp.currency_app.entity.Currency;
import com.restapp.currency_app.repository.CurrencyRepository;
import java.math.BigDecimal;
import java.util.Map;
import java.util.Set;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.modelmapper.ModelMapper;

@ExtendWith(MockitoExtension.class)
public class CurrencyServiceTest {

    @Mock
    private CurrencyDataService currencyDataService;
    @Mock
    private CurrencyRepository currencyRepository;
    @Mock
    private ModelMapper modelMapper;

    @InjectMocks
    private CurrencyService currencyService;

    public static final String TEST_CURRENCY_NAME = "USD";

    @Test
    void getCurrenciesTest() {
        Set<String> currencyNames = Set.of(TEST_CURRENCY_NAME);
        Map<String, BigDecimal> lastCurrencyRates = Map.of(TEST_CURRENCY_NAME, ONE);
        when(currencyDataService.getLastCurrencyRates()).thenReturn(lastCurrencyRates);

        Set<String> actual = currencyService.getCurrencies();

        assertEquals(currencyNames, actual);
        verify(currencyDataService).getLastCurrencyRates();
    }

    @Test
    void getCurrencyRate_currencyRateFound() {
        Map<String, BigDecimal> lastCurrencyRates = Map.of(TEST_CURRENCY_NAME, TWO);
        when(currencyDataService.getLastCurrencyRates()).thenReturn(lastCurrencyRates);

        CurrencyDto actual = currencyService.getCurrencyRate(TEST_CURRENCY_NAME);

        assertEquals(TEST_CURRENCY_NAME, actual.getName());
        assertEquals(TWO, actual.getRate());
        verify(currencyDataService).getLastCurrencyRates();
    }

    @Test
    void getCurrencyRate_currencyRateNotFound() {
        when(currencyDataService.getLastCurrencyRates()).thenReturn(Map.of());

        CurrencyDto actual = currencyService.getCurrencyRate(TEST_CURRENCY_NAME);

        assertNull(actual);
        verify(currencyDataService).getLastCurrencyRates();
    }

    @Test
    void addCurrencyRate_currencyRateAlreadyExist() {
        Map<String, BigDecimal> lastCurrencyRates = Map.of(TEST_CURRENCY_NAME, ONE);
        when(currencyDataService.getLastCurrencyRates()).thenReturn(lastCurrencyRates);
        CurrencyDto currencyDto = new CurrencyDto(TEST_CURRENCY_NAME, ONE);
        Currency currency = new Currency(1L, TEST_CURRENCY_NAME, ONE);
        when(currencyRepository.save(currency)).thenReturn(currency);
        when(currencyRepository.findByName(TEST_CURRENCY_NAME)).thenReturn(new Currency(1L, TEST_CURRENCY_NAME, TWO));
        when(modelMapper.map(currency, CurrencyDto.class)).thenReturn(currencyDto);

        CurrencyDto actual = currencyService.addCurrencyRate(currencyDto);

        assertEquals(currencyDto, actual);
        verify(currencyDataService).getLastCurrencyRates();
        verify(currencyRepository).save(currency);
        verify(currencyDataService).changeLastCurrencyRate(currency);
        verify(modelMapper).map(currency, CurrencyDto.class);
    }

    @Test
    void addCurrencyRate_currencyRateNotExist() {
        CurrencyDto currencyDto = new CurrencyDto(TEST_CURRENCY_NAME, ONE);
        Currency currency = new Currency(null, TEST_CURRENCY_NAME, ONE);
        when(modelMapper.map(currency, CurrencyDto.class)).thenReturn(currencyDto);
        when(currencyDataService.getLastCurrencyRates()).thenReturn(Map.of());
        when(currencyRepository.save(currency)).thenReturn(currency);

        CurrencyDto actual = currencyService.addCurrencyRate(currencyDto);

        assertEquals(currencyDto, actual);
        verify(currencyDataService).getLastCurrencyRates();
        verify(currencyDataService).changeLastCurrencyRate(currency);
        verify(modelMapper).map(currency, CurrencyDto.class);
    }

}
