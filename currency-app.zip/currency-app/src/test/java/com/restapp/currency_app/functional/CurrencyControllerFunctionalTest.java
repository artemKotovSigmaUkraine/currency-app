package com.restapp.currency_app.functional;

import static org.springframework.http.MediaType.APPLICATION_JSON;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;

@SpringBootTest
@AutoConfigureMockMvc
public class CurrencyControllerFunctionalTest {

    @Autowired
    private MockMvc mockMvc;

    public static final String TEST_JSON_CONTENT = "{\"name\":\"ZZZ\",\"rate\":1.00}";

    @Test
    public void testGetCurrenciesEndpoint() throws Exception {
        // Adding single test currency 'ZZZ'
        addDummyCurrencyZZZ();

        // Getting list of all currencies and validate response
        mockMvc.perform(get("/currency"))
            .andExpect(status().isOk())
            .andExpect(content().string(org.hamcrest.Matchers.containsString("\"ZZZ\"")));
    }

    @Test
    public void testGetSingleCurrencyRateEndpoint_currencyIsPresent() throws Exception {
        // Adding single currency 'ZZZ'
        addDummyCurrencyZZZ();

        // Getting currency by name and validate response
        mockMvc.perform(get("/currency/ZZZ"))
            .andExpect(status().isOk());
    }

    @Test
    public void testGetSingleCurrencyRateEndpoint_currencyIsNotPresent() throws Exception {
        // Getting absent currency by name and validate response
        mockMvc.perform(get("/currency/ZZZ"))
            .andExpect(status().is(404));
    }

    @Test
    public void testAddCurrencyRateEndpoint() throws Exception {
        // Checking that the currency 'ZZZ' isn't present
        mockMvc.perform(get("/currency/ZZZ"))
            .andExpect(status().is(404));

        // Adding new currency with name 'ZZZ'
        addDummyCurrencyZZZ();

        // Getting the currency 'ZZZ' by name and verify response
        mockMvc.perform(get("/currency/ZZZ"))
            .andExpect(status().isOk())
            .andExpect(content().string(TEST_JSON_CONTENT));
    }

    private void addDummyCurrencyZZZ() throws Exception {
        mockMvc.perform(post("/currency")
                .contentType(APPLICATION_JSON)
                .content(TEST_JSON_CONTENT))
            .andExpect(status().isOk());
    }

}