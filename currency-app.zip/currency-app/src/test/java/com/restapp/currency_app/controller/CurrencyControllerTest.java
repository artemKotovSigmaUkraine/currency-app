package com.restapp.currency_app.controller;

import static java.math.BigDecimal.ONE;
import static java.math.BigDecimal.TWO;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.http.HttpStatus.NOT_FOUND;
import static org.springframework.http.HttpStatus.NO_CONTENT;
import static org.springframework.http.HttpStatus.OK;

import com.restapp.currency_app.dto.CurrencyDto;
import com.restapp.currency_app.service.CurrencyService;
import java.util.Set;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;

@ExtendWith(MockitoExtension.class)
public class CurrencyControllerTest {

    @Mock
    private CurrencyService currencyService;
    @InjectMocks
    private CurrencyController controller;

    public static final String TEST_CURRENCY_NAME = "USD";

    @Test
    void getCurrenciesTest() {
        Set<String> expected = Set.of(TEST_CURRENCY_NAME);
        when(currencyService.getCurrencies()).thenReturn(expected);

        Set<String> actual = controller.getCurrencies();

        assertEquals(expected, actual);
        verify(currencyService).getCurrencies();
    }

    @Test
    void getCurrencyRate_currencyFound() {
        CurrencyDto expected = new CurrencyDto(TEST_CURRENCY_NAME, ONE);
        when(currencyService.getCurrencyRate(TEST_CURRENCY_NAME)).thenReturn(expected);

        ResponseEntity<CurrencyDto> actual = controller.getCurrencyRate(TEST_CURRENCY_NAME);

        assertEquals(OK, actual.getStatusCode());
        assertEquals(expected, actual.getBody());
        verify(currencyService).getCurrencyRate(TEST_CURRENCY_NAME);
    }

    @Test
    void getCurrencyRate_currencyNotFound() {
        when(currencyService.getCurrencyRate(TEST_CURRENCY_NAME)).thenReturn(null);

        ResponseEntity<CurrencyDto> actual = controller.getCurrencyRate(TEST_CURRENCY_NAME);

        assertEquals(NOT_FOUND, actual.getStatusCode());
        assertNull(actual.getBody());
        verify(currencyService).getCurrencyRate(TEST_CURRENCY_NAME);
    }

    @Test
    void getCurrencyRate_inputParamIsEmpty() {
        ResponseEntity<CurrencyDto> actual = controller.getCurrencyRate(null);

        assertEquals(NO_CONTENT, actual.getStatusCode());
        assertNull(actual.getBody());
        verify(currencyService, never()).getCurrencyRate(anyString());
    }

    @Test
    void addCurrencyRate_rateAdded() {
        CurrencyDto expected = new CurrencyDto(TEST_CURRENCY_NAME, TWO);
        when(currencyService.addCurrencyRate(expected)).thenReturn(expected);

        ResponseEntity<CurrencyDto> actual = controller.addCurrencyRate(expected);

        assertEquals(expected, actual.getBody());
        assertEquals(OK, actual.getStatusCode());
        verify(currencyService).addCurrencyRate(expected);
    }

    @Test
    void addCurrencyRate_inputDataIsEmpty() {
        ResponseEntity<CurrencyDto> actual = controller.addCurrencyRate(null);

        assertNull(actual.getBody());
        assertEquals(NO_CONTENT, actual.getStatusCode());
        verify(currencyService, never()).addCurrencyRate(any());
    }
}
