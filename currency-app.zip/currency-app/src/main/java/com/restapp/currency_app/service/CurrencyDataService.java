package com.restapp.currency_app.service;

import static java.util.stream.Collectors.toMap;
import static org.apache.commons.collections4.CollectionUtils.isNotEmpty;
import static org.springframework.context.annotation.ScopedProxyMode.TARGET_CLASS;

import com.restapp.currency_app.dto.CurrencyDto;
import com.restapp.currency_app.dto.RateDto;
import com.restapp.currency_app.entity.Currency;
import com.restapp.currency_app.repository.CurrencyRepository;
import jakarta.transaction.Transactional;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.commons.collections4.MapUtils;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
@Scope(proxyMode = TARGET_CLASS)
public class CurrencyDataService {

    @Autowired
    private CurrencyRepository currencyRepository;
    @Autowired
    private ModelMapper modelMapper;
    @Autowired
    private CurrencyDataService currencyDataService;
    @Autowired
    private RestTemplate restTemplate;
    @Value("${currency.exchangeratesapi.path}")
    private String exchangeratesapiPath;

    private static Map<String, BigDecimal> lastCurrencyRates = new HashMap<>();

    public Map<String, BigDecimal> getLastCurrencyRates() {
        if (MapUtils.isEmpty(lastCurrencyRates)) {
            List<Currency> currencies = getFreshCurrencyData();
            if (isNotEmpty(currencies)) {
                currencyDataService.updateRatesInDB(currencies);
                lastCurrencyRates = currencies.stream()
                    .collect(toMap(it -> toCurrencyName(it.getName()), Currency::getRate));
            }
        }
        return lastCurrencyRates;
    }

    public void changeLastCurrencyRate(Currency currency) {
        lastCurrencyRates.put(toCurrencyName(currency.getName()), currency.getRate());
    }

    @Transactional
    public void updateRatesInDB(List<Currency> currencies) {
        currencyRepository.deleteAll();
        currencyRepository.flush();
        currencyRepository.saveAll(currencies);
    }

    public List<Currency> getFreshCurrencyData() {
        RateDto rateDto = restTemplate.getForObject(exchangeratesapiPath, RateDto.class);
        return rateDto == null
            ? List.of()
            : rateDto.getRates().entrySet().stream()
                .map(it -> new CurrencyDto(toCurrencyName(it.getKey()), it.getValue()))
                .map(it -> modelMapper.map(it, Currency.class))
                .toList();
    }

    public static String toCurrencyName(String currencyName) {
        return currencyName.toUpperCase();
    }

}
