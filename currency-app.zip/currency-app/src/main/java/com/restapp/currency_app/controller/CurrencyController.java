package com.restapp.currency_app.controller;

import static org.apache.commons.lang3.StringUtils.isEmpty;

import com.restapp.currency_app.dto.CurrencyDto;
import com.restapp.currency_app.service.CurrencyService;
import java.util.Set;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/currency")
public class CurrencyController {

    @Autowired
    private CurrencyService currencyService;

    @GetMapping
    public Set<String> getCurrencies() {
        return currencyService.getCurrencies();
    }

    @GetMapping("/{currency}")
    public ResponseEntity<CurrencyDto> getCurrencyRate(@PathVariable String currency) {
        if (isEmpty(currency)) {
            return ResponseEntity.noContent().build();
        }
        CurrencyDto currencyRate = currencyService.getCurrencyRate(currency);
        return currencyRate == null
            ? ResponseEntity.notFound().build()
            : ResponseEntity.ok(currencyRate);
    }

    @PostMapping
    public ResponseEntity<CurrencyDto> addCurrencyRate(@RequestBody CurrencyDto currencyDto) {
        if (currencyDto == null) {
            return ResponseEntity.noContent().build();
        }
        CurrencyDto savedCurrencyDto = currencyService.addCurrencyRate(currencyDto);
        return ResponseEntity.ok(savedCurrencyDto);
    }

}