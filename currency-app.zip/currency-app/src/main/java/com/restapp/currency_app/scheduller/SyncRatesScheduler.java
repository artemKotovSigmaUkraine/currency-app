package com.restapp.currency_app.scheduller;

import com.restapp.currency_app.entity.Currency;
import com.restapp.currency_app.service.CurrencyDataService;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
public class SyncRatesScheduler {

    @Autowired
    private CurrencyDataService currencyDataService;

    @Scheduled(cron = "${currency.refresh.cron}")
    public void scheduleRatesSyncTask() {
        List<Currency> freshCurrencyData = currencyDataService.getFreshCurrencyData();
        currencyDataService.updateRatesInDB(freshCurrencyData);
    }

}
