package com.restapp.currency_app.repository;

import com.restapp.currency_app.entity.Currency;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CurrencyRepository extends JpaRepository<Currency, Long> {

    Currency findByName(String name);
}
