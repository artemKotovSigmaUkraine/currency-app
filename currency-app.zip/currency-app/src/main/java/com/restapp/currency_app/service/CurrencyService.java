package com.restapp.currency_app.service;

import static com.restapp.currency_app.service.CurrencyDataService.toCurrencyName;
import static org.apache.commons.collections4.MapUtils.isEmpty;

import com.restapp.currency_app.dto.CurrencyDto;
import com.restapp.currency_app.entity.Currency;
import com.restapp.currency_app.repository.CurrencyRepository;
import java.math.BigDecimal;
import java.util.Map;
import java.util.Set;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CurrencyService {

    @Autowired
    private CurrencyRepository currencyRepository;
    @Autowired
    private ModelMapper modelMapper;
    @Autowired
    private CurrencyDataService currencyDataService;

    public Set<String> getCurrencies() {
        return currencyDataService.getLastCurrencyRates().keySet();
    }

    public CurrencyDto getCurrencyRate(String currency) {
        currency = toCurrencyName(currency);
        Map<String, BigDecimal> existingRates = currencyDataService.getLastCurrencyRates();
        if (isEmpty(existingRates) || existingRates.get(currency) == null) {
            return null;
        }

        return new CurrencyDto(currency, existingRates.get(currency));
    }

    public CurrencyDto addCurrencyRate(CurrencyDto currencyDto) {
        Map<String, BigDecimal> existingRates = currencyDataService.getLastCurrencyRates();
        Currency changedCurrency;
        if (existingRates.get(toCurrencyName(currencyDto.getName())) == null) {
            Currency newCurrency = new Currency();
            newCurrency.setName(toCurrencyName(currencyDto.getName()));
            newCurrency.setRate(currencyDto.getRate());
            changedCurrency = currencyRepository.save(newCurrency);
        } else {
            Currency existingCurrency = currencyRepository.findByName(toCurrencyName(currencyDto.getName()));
            existingCurrency.setRate(currencyDto.getRate());
            changedCurrency = currencyRepository.save(existingCurrency);
        }
        currencyDataService.changeLastCurrencyRate(changedCurrency);

        return modelMapper.map(changedCurrency, CurrencyDto.class);
    }

}
