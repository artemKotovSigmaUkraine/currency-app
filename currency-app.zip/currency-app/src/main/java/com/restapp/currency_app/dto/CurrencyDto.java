package com.restapp.currency_app.dto;

import java.math.BigDecimal;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Setter
@Data
public class CurrencyDto {

    private String name;
    private BigDecimal rate;
}
