create SCHEMA IF NOT EXISTS currencydb_schema;

create TABLE currencydb_schema.currency (
  id SERIAL primary key not null,
  name varchar(50) UNIQUE not null,
  rate numeric(12,2) not null
);